import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

print("Generating pdf: graphs.pdf")

with open('smat.out') as f:
    lines = f.readlines()


    tmpx = [line.split()[0] for line in lines]
    tmpy = [line.split()[1] for line in lines]

    i=0
    x=[]
    y=[]
    while float(tmpy[i]) < 1. :
		x.append(float(tmpx[i]))
		y.append(float(tmpy[i]))
		i=i+1
#    print(x)
#    print(y)

pp = PdfPages('graphs.pdf')

figsmat = plt.figure()

ax1 = figsmat.add_subplot(111)

ax1.set_title("S-mat")    
ax1.set_xlabel('x label')
ax1.set_ylabel('y label')

ax1.plot(x,y, c='r')

pp.savefig(figsmat)



with open('elasticxs.dat') as f:
    lines = f.readlines()
    lines.pop()

    x = [line.split()[0] for line in lines]
    y = [line.split()[1] for line in lines]
    for i in range(0,len(y)):
		y[i] = float(y[i])
		x[i] = float(x[i])
#    print(x)
#    print(y)

xexp= []
yexp= []
dyexp= []
try:
	f = open("elast_exp.dat")
except IOError:
	print("No elastic data")
else:
	with open('elast_exp.dat') as f:
		lines = f.readlines()
		xexp = [line.split()[0] for line in lines]
		yexp = [line.split()[1] for line in lines]
		dyexp = [line.split()[2] for line in lines]
		for i in range(0,len(yexp)):
			xexp[i] = float(xexp[i])
			yexp[i] = float(yexp[i])
			dyexp[i] = float(dyexp[i])

figelas = plt.figure()

ax1 = figelas.add_subplot(111)

ax1.set_title("Ratio to Rutherford")    
ax1.set_xlabel('x label')
ax1.set_ylabel('y label')

ax1.plot(x,y, c='r')
if xexp != '[]':
	ax1.errorbar(xexp, yexp,yerr = dyexp, fmt ='o')

pp.savefig(figelas)
ax1.set_yscale('log')
pp.savefig(figelas)

try:
	f = open("inelastic1xs.dat")
except IOError:
	print("No inelastic")
else:
	with open('inelastic1xs.dat') as f:
		lines = f.readlines()
		lines.pop()
		x = [line.split()[0] for line in lines]
		y = [line.split()[1] for line in lines]
		for i in range(0,len(y)):
			y[i] = float(y[i])
			x[i] = float(x[i])
	
	xexp= []
	yexp= []
	dyexp= []
	try:
		f = open("inel1_exp.dat")
	except IOError:
		print("No inelastic data")
	else:
		with open('inel1_exp.dat') as f:
			lines = f.readlines()
			xexp = [line.split()[0] for line in lines]
			yexp = [line.split()[1] for line in lines]
			dyexp = [line.split()[2] for line in lines]
			for i in range(0,len(yexp)):
				xexp[i] = float(xexp[i])
				yexp[i] = float(yexp[i])
				dyexp[i] = float(dyexp[i])
	
	figinel1 = plt.figure()
	ax1 = figinel1.add_subplot(111)
	ax1.set_title("Inelastic xs")    
	ax1.set_xlabel('x label')
	ax1.set_ylabel('y label')
	ax1.plot(x,y, c='r')
	if xexp != '[]':
		ax1.errorbar(xexp, yexp,yerr = dyexp, fmt ='o')
	pp.savefig(figinel1)
	ax1.set_yscale('log')
	pp.savefig(figinel1)
	
	
try:
	f = open("inelastic2xs.dat")
except IOError:
	print("No inelastic")
else:
	with open('inelastic2xs.dat') as f:
		lines = f.readlines()
		lines.pop()
		x = [line.split()[0] for line in lines]
		y = [line.split()[1] for line in lines]
		for i in range(0,len(y)):
			y[i] = float(y[i])
			x[i] = float(x[i])
	
	figinel2 = plt.figure()
	ax1 = figinel2.add_subplot(111)
	ax1.set_title("Inelastic xs")    
	ax1.set_xlabel('x label')
	ax1.set_ylabel('y label')
	ax1.plot(x,y, c='r')
	pp.savefig(figinel2)
	ax1.set_yscale('log')
	pp.savefig(figinel2)

pp.close()

