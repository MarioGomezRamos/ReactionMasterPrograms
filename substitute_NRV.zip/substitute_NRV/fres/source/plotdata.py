import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

print("Generating pdf: graphs.pdf")

pp = PdfPages('graphs.pdf')

#Potential
try:
    f = open("potential.dat")
except IOError:
    print("No potential")
else:
    with open('potential.dat') as f:
         lines = f.readlines()
         r = [line.split()[0] for line in lines]
         vr = [line.split()[1] for line in lines]
         vi = [line.split()[2] for line in lines]
         vso = [line.split()[3] for line in lines]
         defc2 = [line.split()[4] for line in lines]
         defr2 = [line.split()[5] for line in lines]
         defi2 = [line.split()[6] for line in lines]
         defc3 = [line.split()[7] for line in lines]
         defr3 = [line.split()[8] for line in lines]
         defi3 = [line.split()[9] for line in lines]
         ener = [line.split()[10] for line in lines]
         for i in range(0,len(r)):
              r[i] = float(r[i])
              vr[i] = float(vr[i])
              vi[i] = float(vi[i])
              vso[i] = float(vso[i])
              defc2[i] = float(defc2[i])
              defr2[i] = float(defr2[i])
              defi2[i] = float(defi2[i])
              defc3[i] = float(defc3[i])
              defr3[i] = float(defr3[i])
              defi3[i] = float(defi3[i])
              ener[i] = float(ener[i])

    figpot = plt.figure()
    ax1 = figpot.add_subplot(111)

    ax1.set_title("Potential")    
    ax1.set_xlabel('r (fm)')
    ax1.set_ylabel('V,W (MeV)')
    ax1.plot(r,vr, c='k',label='Real')
    ax1.plot(r,vi, c='r',label='Imag.')
    summ = 0
    for i in vso:
        summ = summ+abs(i)
    if summ> 1.:
        ax1.plot(r,vso, c='g',label='Spin-Orbit')
    ax1.plot(r,ener, c='r',linestyle='dashed',label='Energy')
    ax1.legend()
    pp.savefig(figpot)

    sumc2 = 0
    for i in defc2:
        sumc2 = sumc2+abs(i)
    sumr2 = 0
    for i in defr2:
        sumr2 = sumr2+abs(i)
    sumi2 = 0
    for i in defi2:
        sumi2 = sumi2+abs(i)
    
    if (sumc2 >1.) | (sumr2 >1.) | (sumi2 >1.):
        figdef2 = plt.figure()
        ax1 = figdef2.add_subplot(111)
        ax1.set_title("Quadrupole potential")    
        ax1.set_xlabel('r (fm)')
        ax1.set_ylabel('V,W (MeV)')
        if sumc2 >1.:
            ax1.plot(r,defc2, c='b',label='Coulomb')
        if sumr2 >1.:
            ax1.plot(r,defr2, c='k',label='Real')
        if sumi2> 1.:
            ax1.plot(r,defi2, c='r',label='Imag')
        ax1.legend()
        pp.savefig(figdef2)

    sumc3 = 0
    for i in defc3:
        sumc3 = sumc3+abs(i)
    sumr3 = 0
    for i in defr3:
        sumr3 = sumr3+abs(i)
    sumi3 = 0
    for i in defi3:
        sumi3 = sumi3+abs(i)
    
    if (sumc3 >1.) | (sumr3 >1.) | (sumi3>1.):
        figdef3 = plt.figure()
        ax1 = figdef3.add_subplot(111)
        ax1.set_title("Octupole potential")    
        ax1.set_xlabel('r (fm)')
        ax1.set_ylabel('V,W (MeV)')
        if sumc3 >1.:
            ax1.plot(r,defc3, c='b',label='Coulomb')
        if sumr3 >1.:
            ax1.plot(r,defr3, c='k',label='Real')
        if sumi3> 1.:
            ax1.plot(r,defi3, c='r',label='Imag')
        ax1.legend()
        pp.savefig(figdef3)

with open('turning_points.dat') as f:
    lines = f.readlines()
    x = [line.split()[0] for line in lines]
    y = [line.split()[1] for line in lines]
    yc = [line.split()[2] for line in lines]
    for i in range(0,len(y)):
         y[i] = float(y[i])
         x[i] = float(x[i])
         yc[i]= float(yc[i])
figturn = plt.figure()
ax1 = figturn.add_subplot(111)         
ax1.set_title("Turning points")    
ax1.set_xlabel('b (fm)')
ax1.set_ylabel('r_turn (fm)')
ax1.plot(x,y, c='k',label='Nuc+Coul')
ax1.plot(x,yc, c='r',label='Coulomb')
pp.savefig(figturn)

with open('deflection_function.dat') as f:
    tmplines = f.readlines()
    lines = [line for line in tmplines if line.split()[0] != '#']
    x = [line.split()[0] for line in lines]
    y = [line.split()[1] for line in lines]
    yc = [line.split()[2] for line in lines]
    for i in range(0,len(y)):
         y[i] = float(y[i])
         x[i] = float(x[i])
         yc[i]= float(yc[i])
figdefl = plt.figure()
ax1 = figdefl.add_subplot(111) 
ax1.set_title("Deflection function")    
ax1.set_xlabel('b (fm)')
ax1.set_ylabel('theta (deg)')
ax1.plot(x,y, c='k',label='Nuc+Coul')
ax1.plot(x,yc, c='r',label='Coulomb')
pp.savefig(figdefl)


with open('smat.out') as f:
    lines = f.readlines()


    tmpx = [line.split()[0] for line in lines]
    tmpy = [line.split()[1] for line in lines]

    i=0
    x=[]
    y=[]
    while float(tmpy[i]) < 1. :
         x.append(float(tmpx[i]))
         y.append(float(tmpy[i]))
         i=i+1
#    print(x)
#    print(y)



figsmat = plt.figure()

ax1 = figsmat.add_subplot(111)

ax1.set_title("|S|^2")    
ax1.set_xlabel('L')
ax1.set_ylabel('|S|^2')

ax1.plot(x,y, c='r')

pp.savefig(figsmat)



with open('elasticxs.dat') as f:
    lines = f.readlines()
    lines.pop()

    x = [line.split()[0] for line in lines]
    y = [line.split()[1] for line in lines]
    for i in range(0,len(y)):
         y[i] = float(y[i])
         x[i] = float(x[i])
#    print(x)
#    print(y)

xexp= []
yexp= []
dyexp= []
try:
    f = open("elast_exp.dat")
except IOError:
    print("No elastic data")
else:
    with open('elast_exp.dat') as f:
         tmplines = f.readlines()
         lines =[line for line in tmplines if len(line) > 1]
         xexp = [line.split()[0] for line in lines]
         yexp = [line.split()[1] for line in lines]
         dyexp = [line.split()[2] for line in lines]
         for i in range(0,len(yexp)):
              xexp[i] = float(xexp[i])
              yexp[i] = float(yexp[i])
              dyexp[i] = float(dyexp[i])

figelas = plt.figure()

ax1 = figelas.add_subplot(111)

ax1.set_title("Ratio to Rutherford")    
ax1.set_xlabel('theta (deg)')
ax1.set_ylabel('sigma/sigma_R')

ax1.plot(x,y, c='r')
if xexp != '[]':
    ax1.errorbar(xexp, yexp,yerr = dyexp, fmt ='o')

pp.savefig(figelas)
ax1.set_yscale('log')
pp.savefig(figelas)

try:
    f = open("inelastic1xs.dat")
except IOError:
    print("No inelastic")
else:
    with open('inelastic1xs.dat') as f:
         lines = f.readlines()
         lines.pop()
         x = [line.split()[0] for line in lines]
         y = [line.split()[1] for line in lines]
         for i in range(0,len(y)):
              y[i] = float(y[i])
              x[i] = float(x[i])

    xexp= []
    yexp= []
    dyexp= []
    try:
         f = open("inel1_exp.dat")
    except IOError:
         print("No inelastic data")
    else:
         with open('inel1_exp.dat') as f:
              tmplines = f.readlines()
              lines =[line for line in tmplines if len(line) > 1]
              xexp = [line.split()[0] for line in lines]
              yexp = [line.split()[1] for line in lines]
              dyexp = [line.split()[2] for line in lines]
              for i in range(0,len(yexp)):
                   xexp[i] = float(xexp[i])
                   yexp[i] = float(yexp[i])
                   dyexp[i] = float(dyexp[i])
	
    figinel1 = plt.figure()
    ax1 = figinel1.add_subplot(111)
    ax1.set_title("Inelastic xs")    
    ax1.set_xlabel('theta (deg)')
    ax1.set_ylabel('sigma (mb)')
    ax1.plot(x,y, c='r')
    if xexp != '[]':
         ax1.errorbar(xexp, yexp,yerr = dyexp, fmt ='o')
    pp.savefig(figinel1)
    ax1.set_yscale('log')
    pp.savefig(figinel1)


try:
    f = open("inelastic2xs.dat")
except IOError:
    print("No inelastic")
else:
    with open('inelastic2xs.dat') as f:
         lines = f.readlines()
         lines.pop()
         x = [line.split()[0] for line in lines]
         y = [line.split()[1] for line in lines]
         for i in range(0,len(y)):
              y[i] = float(y[i])
              x[i] = float(x[i])
    xexp=[]
    try:
         f = open("inel1_exp.dat")
    except IOError:
         print("No inelastic data")
    else:
         with open('inel2_exp.dat') as f:
              tmplines = f.readlines()
              lines =[line for line in tmplines if len(line) > 1]
              xexp = [line.split()[0] for line in lines]
              yexp = [line.split()[1] for line in lines]
              dyexp = [line.split()[2] for line in lines]
              for i in range(0,len(yexp)):
                   xexp[i] = float(xexp[i])
                   yexp[i] = float(yexp[i])
                   dyexp[i] = float(dyexp[i])

    figinel2 = plt.figure()
    ax1 = figinel2.add_subplot(111)
    ax1.set_title("Inelastic xs")    
    ax1.set_xlabel('theta (deg)')
    ax1.set_ylabel('sigma (mb)')
    ax1.plot(x,y, c='r')
    if xexp != '[]':
         ax1.errorbar(xexp, yexp,yerr = dyexp, fmt ='o')
    pp.savefig(figinel2)
    ax1.set_yscale('log')
    pp.savefig(figinel2)




pp.close()

